import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class MathsService {
  add(a,b){
    return a+b
  }
  subtraction(a,b){
    return a-b
  }
  multiply(a,b){
    return a * b
  }
  division(a,b){
    return a/b
  }

  display(name,id,salary){
    alert("Name is" +name+" id is "+  id+ " Salary is " + salary)
  }
  constructor() { }
}
