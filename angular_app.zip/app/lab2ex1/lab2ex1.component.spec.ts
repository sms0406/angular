import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Lab2ex1Component } from './lab2ex1.component';

describe('Lab2ex1Component', () => {
  let component: Lab2ex1Component;
  let fixture: ComponentFixture<Lab2ex1Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Lab2ex1Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Lab2ex1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
