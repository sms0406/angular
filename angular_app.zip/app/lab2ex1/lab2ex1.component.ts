import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lab2ex1',
  templateUrl: './lab2ex1.component.html',
  styleUrls: ['./lab2ex1.component.css']
})
export class Lab2ex1Component implements OnInit {
 flag=false
 flag1=false
 index
  employees=[
        {empId:1001,empName:"Rahul",empSal:9000,empDep:"Java"},
        {empId:1002,empName:"Sachin",empSal:19000,empDep:"OraApps"},
        {empId:1003,empName:"Vikash",empSal:29000,empDep:"BI"},
  ];
  constructor() { }

  ngOnInit() {
  }
  addMethod(form)
  {
    this.employees.push(form)
    this.flag=false
  }
  enable()
  {
    this.flag=true
    this.flag1=false
  }
  deleteMethod(i)
  {
    this.employees.splice(i,1);
  }
  updateIndex(i)
  {
    this.index=i;
    this.flag=false
    this.flag1=true
  }
  updateMethod(add)
  {
    if(add.empId!=null)  
      this.employees[this.index].empId=add.empId;
    if(add.empName!=null)
      this.employees[this.index].empName=add.empName;
    if(add.empSal!=null)
      this.employees[this.index].empSal=add.empSal;
    if(add.empDep!=null)
      this.employees[this.index].empDep=add.empDep;
    this.flag=false
  }
}
