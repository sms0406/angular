import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { Lab1Component } from './lab1/lab1.component';
import { UiComponent } from './ui/ui.component';
import { Lab2ex1Component } from './lab2ex1/lab2ex1.component';
import { Lab2ex2Component } from './lab2ex2/lab2ex2.component';
import { Lab3Component } from './lab3/lab3.component';
import { Lab4Component } from './lab4/lab4.component';

@NgModule({
  declarations: [
    AppComponent,
    Lab1Component,
    UiComponent,
    Lab2ex1Component,
    Lab2ex2Component,
    Lab3Component,
    Lab4Component,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
