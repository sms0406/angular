import { DataTableModule } from 'angular-6-datatable';
import { AppRoutingModule } from './app-routing/app-routing.module';
import { ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import { ListMoviesComponent } from './list-movies/list-movies.component';
import {HttpClientModule} from '@angular/common/http';
import { AddMoviesComponent } from './add-movies/add-movies.component';
import { EditMoviesComponent } from './edit-movies/edit-movies.component';
import { LoginComponent } from './login/login.component';
import {FormsModule} from '@angular/forms';


@NgModule({
  declarations: [
    AppComponent,
    ListMoviesComponent,
    AddMoviesComponent,
    EditMoviesComponent,
    LoginComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    ReactiveFormsModule,
    DataTableModule,
    AppRoutingModule,
    FormsModule                     
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
