import { Component, OnInit } from '@angular/core';
import data from '../data/db.json';
@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  products=data;
  nameValidation=false;
  constructor() { }
  ngOnInit() {
  }
  search(device)
  {
    if (!device) {
      this.nameValidation = true;
      return
    }
    else
      this.nameValidation=false;    
    
  }
  searchByName(event) {
    this.products=  this.products.filter(singleItem =>
     singleItem.name.toLowerCase().includes(event.target.value.toLowerCase())
    )
  }
  searchByCategory(event) {
    this.products=  this.products.filter(singleItem =>
     singleItem.category.toLowerCase().includes(event.target.value.toLowerCase())
    )
  }
  
}