import { Component, OnInit } from '@angular/core';
import data from '../data/db.json';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit {
  products=data;
  deleted=false;
  constructor() { }

  ngOnInit() {
  }
  deleteMethod(i)
  {
    this.products.splice(i,1); //DELETING THE VALUE FROM THE PRODUCTS 1 TIME BY INDEX
    this.deleted=true; //OBJECT TO SHOW ALERT MESSAGE ON HTML
  }
}
