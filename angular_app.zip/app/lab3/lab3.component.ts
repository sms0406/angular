import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lab3',
  templateUrl: './lab3.component.html',
  styleUrls: ['./lab3.component.css']
})
export class Lab3Component implements OnInit {
  idValidation = false
  nameValidation = false;
  costValidation = false;
  radioValidation=false;
  selectValidation=false;
  constructor() { }
  ngOnInit() {
  }
  addDetails(form)
  {
    if(!form.pid){
      this.idValidation=true;
      return
    }
    else
      this.idValidation=false;
    if (!form.pname) {
      this.nameValidation = true;
      return
    }
    else
      this.nameValidation=false;
    if(!form.pcost)
    {
      this.costValidation=true;
      return
    }
    else
      this.costValidation=false
    if(!form.selection)
    {
      this.radioValidation=true;
      return
    }
    else  
      this.radioValidation=false
    if(!form.selection)
    {
      this.radioValidation=true;
      return
    }
    else  
       this.radioValidation=false
    if(!form.multiple)
    {
      this.selectValidation=true;
      return
    }
    else  
       this.selectValidation=false
    console.log(form.pid)
    console.log(form.pname)
    console.log(form.pcost)
    console.log(form.selection)
    console.log(form.multiple)
    if(form.bigbazar==true)
      console.log("Big Bazar")
    if(form.dmart==true)
      console.log("DMart")
    if(form.reliance==true)
      console.log("Reliance")
    if(form.megastore==true)
      console.log("Mega Store")
  }
}
