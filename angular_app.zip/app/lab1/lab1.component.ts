import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lab1',
  templateUrl: './lab1.component.html',
  styleUrls: ['./lab1.component.css']
})
export class Lab1Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  callMethod(id,name,salary,dept)
  {
    alert(id+" " +name+ " " +salary+ " "+dept)
  }
}
