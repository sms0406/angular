import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SearchComponent } from './search/search.component';
import { ListComponent } from './list/list.component';

//IMPORTING PAGE ROUTES

const routes: Routes = [
  {
    path:"", //THIS IS A DEFAULT PATH (HOME - SEARCH)
    component:SearchComponent
  },
  {
    path:"list", //THIS IS PRODUCT LIST PATH ( DELETE METHOD )
    component:ListComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
