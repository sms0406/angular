import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FormComponent } from './form/form.component';
import { FormsModule } from '@angular/forms';
import { ExponentialPipe } from './exponential.pipe';
import { AdditionPipe } from './addition.pipe';
import { ShowstudentsComponent } from './showstudents/showstudents.component';
import { ShowemployeesComponent } from './showemployees/showemployees.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FormComponent,
    ExponentialPipe,
    AdditionPipe,
    ShowstudentsComponent,
    ShowemployeesComponent,
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
