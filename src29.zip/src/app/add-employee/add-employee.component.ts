import { Component, OnInit } from '@angular/core';

import data from '../../data/employeedata.json'

@Component({
  selector: 'app-add-employee',
  templateUrl: './add-employee.component.html',
  styleUrls: ['./add-employee.component.css']
})
export class AddEmployeeComponent implements OnInit {
  employees = data
  IdValidation = false
  nameValidation = false;
  salaryValidation = false
  constructor() { }

  ngOnInit() {
  }

  addEmployee(form) {
    console.log(form.id, form.name, form.salary)
    if (!form.id) {
      this.IdValidation = true;
      return
    } else {
      this.IdValidation = false
    }

    if (!form.name) {
      this.nameValidation = true;
      return
    } else {
      this.nameValidation = false
    }

    if (!form.salary) {
      this.salaryValidation = true;
      return
    } else {
      this.salaryValidation = false
    }
    this.employees.push(form)
  }

}
