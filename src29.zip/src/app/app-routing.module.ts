import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ShowstudentsComponent } from './showstudents/showstudents.component'
import { ShowemployeesComponent } from './showemployees/showemployees.component'
import { FormComponent } from './form/form.component'
import { AddEmployeeComponent } from './add-employee/add-employee.component'
import {HttpComponent} from './http/http.component'

const routes: Routes = [
  {

    path: 'showStudent',
    component: ShowstudentsComponent

  },
  {

    path: 'showEmployee',
    component: ShowemployeesComponent

  },

  {

    path: 'addEmployee',
    component: AddEmployeeComponent

  },


  {

    path: '',
    component: HttpComponent

  }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
