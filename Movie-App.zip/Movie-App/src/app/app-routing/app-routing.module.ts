import { AddMoviesComponent } from './../add-movies/add-movies.component';
import { EditMoviesComponent } from './../edit-movies/edit-movies.component';
import { LoginComponent } from './../login/login.component';
import { ListMoviesComponent } from './../list-movies/list-movies.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {Routes, RouterModule} from '@angular/router';

export const routes: Routes= [
  {path: '', component:LoginComponent,pathMatch:'full'},
  {path: 'login', component:LoginComponent},
  {path: 'list-movies', component:ListMoviesComponent},
  {path: 'edit-movies', component:EditMoviesComponent},
  {path: 'add-movies', component:AddMoviesComponent},
 
]


@NgModule({
  imports: [
    CommonModule,RouterModule.forRoot(routes)
  ],
  exports: [RouterModule],
  declarations: []
})
export class AppRoutingModule { }
