import { Component, OnInit } from '@angular/core';
import { MathsService } from '../maths.service';
import data from '../../data/employeedata.json'


@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.css']
})
export class FormComponent implements OnInit {
  employees = data
  // employees = [
  //   {
  //     id:'1111',
  //     name:'Dollar '
  //   },
  //   {
  //     id:'2222',
  //     name:'Capegemini '
  //   },
  //   {
  //     id:'33333',
  //     name:'Chennai '
  //   }
    
  // ]
  showDiv = false
  constructor(private service: MathsService) { }

  ngOnInit() {
  }
  getData(name,id,salary) {
    this.showDiv = true
    this.service.display(name,id,salary)
  }

  deleteEmployee(i){
    this.employees.splice(i,1)
  }

}
