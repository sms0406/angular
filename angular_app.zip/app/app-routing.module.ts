import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UiComponent } from './ui/ui.component';
import { Lab1Component } from './lab1/lab1.component';
import { Lab2ex1Component } from './lab2ex1/lab2ex1.component';
import { Lab2ex2Component } from './lab2ex2/lab2ex2.component';
import { Lab3Component } from './lab3/lab3.component';
import { Lab4Component } from './lab4/lab4.component';
const routes: Routes = [
  {
  path:"",
  component:UiComponent
  },
  {
    path:"lab1",
    component:Lab1Component
  },
  {
    path:"lab2ex1",
    component:Lab2ex1Component
  },
  {
    path:"lab2ex2",
    component:Lab2ex2Component
  },
  {
    path:"lab3",
    component:Lab3Component
  },
  {
    path:"lab4",
    component:Lab4Component
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
