import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ShowstudentsComponent } from './showstudents/showstudents.component'
import { ShowemployeesComponent } from './showemployees/showemployees.component'
import { FormComponent } from './form/form.component'

const routes: Routes = [
  {

    path: 'showStudent',
    component: ShowstudentsComponent

  },
  {

    path: 'showEmployee',
    component: ShowemployeesComponent

  },
  {

    path: '',
    component: FormComponent

  }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
