import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FormComponent } from './form/form.component';
import { FormsModule } from '@angular/forms';
import { ExponentialPipe } from './exponential.pipe';
import { AdditionPipe } from './addition.pipe';
import { ShowstudentsComponent } from './showstudents/showstudents.component';
import { ShowemployeesComponent } from './showemployees/showemployees.component';
import { AddEmployeeComponent } from './add-employee/add-employee.component';
import { HttpClientModule } from '@angular/common/http';
import { HttpComponent } from './http/http.component'
@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FormComponent,
    ExponentialPipe,
    AdditionPipe,
    ShowstudentsComponent,
    ShowemployeesComponent,
    AddEmployeeComponent,
    HttpComponent,
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
